<?php
namespace FS\Dealer\Controller\Adminhtml\Accept;

use Magento\Backend\App\Action;
use FS\Dealer\Model\Dealer\Tax\Tnc as TncModel;

class Save extends Action
{
	 /**
     * @var TncModel
     */
    protected $tncModel;

    public function __construct(
        Action\Context $context,
		TncModel $tncModel
	)
	{
		parent::__construct($context);
		$this->tncModel = $tncModel;
    }

    /**
     * execute method
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $dealerCode = $this->getRequest()->getPost('dealer_code');
		if (empty($dealerCode)) {
			$this->messageManager->addErrorMessage(__('Please mark checkbox as checked.'));
			$resultRedirect->setPath('*/*/index');
			return $resultRedirect;
		}
		$tncInfo = $this->tncModel->load($dealerCode, 'dealer_code');
		$tncContent = $this->getRequest()->getPost('tnc_content');
		$tncInfo->setStatus(1)->setDealerCode($dealerCode)->setTncContent($tncContent)->setAcceptedAt(date('Y-m-d H:i:s'))->save();
		$this->messageManager->addSuccessMessage(__('TAX TNC accepted successfully by Dealer.'));
		$resultRedirect->setPath('*/*/index');
		return $resultRedirect;
    }
}
