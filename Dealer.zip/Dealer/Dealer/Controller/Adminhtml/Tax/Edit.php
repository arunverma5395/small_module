<?php
/**
 *
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace FS\Dealer\Controller\Adminhtml\Tax;

use Magento\Framework\Locale\Resolver;

class Edit extends \FS\Dealer\Controller\Adminhtml\Dealer\Tax
{
	/**
     * @return void
     */
    public function execute()
    {
        $entityId = $this->getRequest()->getParam('entity_id');
        /** @var \FS\Dealer\Model\Dealer\Tax $model */
        $model = $this->_dealerTaxFactory->create();
		//echo "<pre>";exit;
		
        //if ($entityId) {
            $model->load($entityId);
            //echo "<pre>";print_r($model->getData());exit;
            if (!$model->getId()) {
                $this->messageManager->addError(__('This user no longer exists.'));
                $this->_redirect('dealer/*/');
                return;
            }
        //} else {
            //$model->setInterfaceLocale(Resolver::DEFAULT_LOCALE);
        //}

        // Restore previously entered form data from session
        $data = $this->_session->getDealerTaxData(true);
        if (!empty($data)) {
            $model->setData($data);
        }

        $this->_coreRegistry->register('dealer_tax_data', $model);

        if (isset($entityId)) {
            $breadcrumb = __('Edit Dealer Tax');
        } else {
            $breadcrumb = __('New Dealer Tax');
        }
        $this->_initAction()->_addBreadcrumb($breadcrumb, $breadcrumb);
        $this->_view->getPage()->getConfig()->getTitle()->prepend(__('Dealer Tax'));
        $this->_view->getPage()->getConfig()->getTitle()->prepend($model->getId() ? $model->getName() : __('New Dealer Tax'));
        $this->_view->renderLayout();
    }
}
