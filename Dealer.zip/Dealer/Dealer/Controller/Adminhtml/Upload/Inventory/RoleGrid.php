<?php
/**
 *
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace FS\Dealer\Controller\Adminhtml\Upload\Inventory;

use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\App\Action\HttpPostActionInterface;
use FS\Dealer\Controller\Adminhtml\Dealer as DealerAction;

class RoleGrid extends DealerAction implements HttpGetActionInterface, HttpPostActionInterface
{
    /**
     * @return void
     */
    public function execute()
    {
        $this->_view->loadLayout(false);
        $this->_view->renderLayout();
    }
}
