<?php
namespace FS\Dealer\Controller\Adminhtml\Upload;

class InventoryUpload extends \Magento\Backend\App\Action
{	
	protected $product;
	
	protected $dealerUploadInventory;
	
	protected $dealerHelper;
	
	public function __construct(
		\Magento\Backend\App\Action\Context $context,
        \Magento\Framework\File\Csv $csvProcessor,
        \Magento\Catalog\Model\Product $product,
        \Havells\Dealer\Model\ResourceModel\Dealer\Inventry\CollectionFactory $inventryCollectionFactory,
        \FS\Dealer\Helper\Data $dealerHelper
	)
	{
        $this->csvProcessor = $csvProcessor;
        $this->product = $product;
        $this->inventryCollectionFactory = $inventryCollectionFactory;
        $this->dealerHelper = $dealerHelper;
                
        parent::__construct($context);		
	}


	public function execute()
    {
        if (!isset($_FILES['importfile']['tmp_name'])) {
			$this->messageManager->addError(__('Invalid file upload attempt.'));
			$this->_redirect('*/*/inventory');
			return;
		}		
		$dealerId = $this->dealerHelper->getLoggedInUser()->getId();
		$dealerCode = $this->dealerHelper->getLoggedInUser()->getUsername();
		try {
			$csvData = $this->csvProcessor->getData($_FILES['importfile']['tmp_name']);
			if (empty($csvData)) {
				$this->messageManager->addError(__('Uploaded file is blank'));
				$this->_redirect('*/*/inventory');
				return;
			}
			unset($csvData[0]);
			foreach ($csvData as $row) {
				$stockItem = $this->inventryCollectionFactory->create()
					->addFieldToFilter("dealer_code", $dealerCode)
					->addFieldToFilter("sku", $row[1])->getFirstItem();
				
				$stockItem->setDealerCode($dealerCode)
					->setDealerId($dealerId)
					->setSku($row[1])
					->setItemDescription($row[2])
					->setItemColor($row[3])
					->setItemDivisionCode($row[4])
					->setInventry($row[5])
					->save();
			}
			$this->messageManager->addSuccess(__('File Data Imported Successfully.'));
		} catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
        }

		$this->_redirect('*/*/inventory');
		return;	
    }    
}
