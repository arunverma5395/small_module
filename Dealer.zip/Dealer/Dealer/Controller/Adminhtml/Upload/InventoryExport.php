<?php
namespace FS\Dealer\Controller\Adminhtml\Upload;

class InventoryExport extends \Magento\Backend\App\Action
{
	protected $product;
	
	protected $dealerHelper;	

	protected $category;
	
	protected $csvProcessor;
	
	protected $fileFactory;
	
	protected $directoryList;
	
	public function __construct(
		\Magento\Backend\App\Action\Context $context,        
        \Magento\Catalog\Model\Product $product,
        \FS\Dealer\Helper\Data $dealerHelper,        
        \Magento\Catalog\Model\Category $category,
        \Magento\Framework\File\Csv $csvProcessor,
        \FS\Dealer\Model\Dealer\Upload\InventoryFactory $inventoryFactory,
        \Magento\Framework\App\Response\Http\FileFactory $fileFactory,
        \Magento\Framework\App\Filesystem\DirectoryList $directoryList        
	)
	{        
        $this->product = $product;
        $this->dealerHelper = $dealerHelper;        
        $this->category = $category;
        $this->csvProcessor = $csvProcessor;
        $this->fileFactory = $fileFactory;
        $this->directoryList = $directoryList;
        $this->inventoryFactory=$inventoryFactory;
        parent::__construct($context);		
	}


	public function execute()
    {		
		$catIds = $this->getRequest()->getParam('cat_ids');
		$catIdsArray = explode(",", $catIds);
		//echo "<pre>";print_r($data);exit;
				
		$fileName   = 'sample_dealer_inventory.csv';
    	$filePath = $this->directoryList->getPath(\Magento\Framework\App\Filesystem\DirectoryList::VAR_DIR)
        	. "/" . $fileName;	
		
		$exportData = $this->getExportData($catIdsArray);				
		$this->csvProcessor
    	    ->setDelimiter(',')
        	->setEnclosure('"')
        	->saveData(
            	$filePath,
            	$exportData
        	);
				
		return $this->fileFactory->create(
         $fileName,
         [
             'type' => "filename",
             'value' => $fileName,
             'rm' => true,
         ],
            \Magento\Framework\App\Filesystem\DirectoryList::VAR_DIR,
         'application/octet-stream'
		);
	
    }
    
    protected function getExportData($catIdsArray){
		
		$result [] = ['Dealer_code','sku','Product_Description','color','division','current_stock'];
		$dealer_code = $this->dealerHelper->getLoggedInUser()->getUsername();
		$roleId=$this->dealerHelper->getLoggedInUserRoleId();

		//print_r($catIdsArray);
		$productArray = [];
		foreach($catIdsArray as $catId){
			$catgegoryCollection = $this->category->load($catId);
			$prod = $catgegoryCollection->getProductCollection();
			//print_r($prod->getSize());
			foreach($prod as $pro) {
				//echo 'foreach';
				$catalog = $this->product->load($pro->getId());
				if($roleId=3)
				{
					$collection=$this->inventoryFactory->create()->getCollection()->addFieldToFilter('main_table.dealer_code',$dealer_code)->addFieldToFilter('sku',$catalog->getSku())->getFirstItem();
				}
				else
				{
					$collection=$this->inventoryFactory->create()->getCollection()->addFieldToFilter('main_table.dealer_code',$dealer_code)->addFieldToFilter('sku',$catalog->getSku());
				}
			// 	print_r($collection->getSelect()->__toString());
			// die('herre');
				
				if(!in_array($pro->getId(),$productArray)){
					$productArray[]=$pro->getId();	
					if(!empty($collection))
					{
						if($catalog->getStatus()==1) {						
							$result [] = [
								$dealer_code,
								$pro->getSku(),
								preg_replace( "/\r|\n/", "", strip_tags($catalog->getName())),
								$catalog->getAttributeText('color'),
								$catalog->getDivisionCode(),
								$collection->getInventry()
							]; 
						}
					}			
					
				}
			}
		}
		
		return $result;
	}
}
