<?php
namespace FS\Dealer\Controller\Adminhtml\Upload;

class TaxUpload extends \Magento\Backend\App\Action
{	
	protected $product;
	
	protected $dealerTax;
	
	protected $dealerHelper;
	
	public function __construct(
		\Magento\Backend\App\Action\Context $context,
        \Magento\Framework\File\Csv $csvProcessor,
        \Magento\Catalog\Model\Product $product,
        \FS\Dealer\Model\Dealer\Tax $dealerTax,
        \FS\Dealer\Helper\Data $dealerHelper
	)
	{
        $this->csvProcessor = $csvProcessor;
        $this->product = $product;
        $this->dealerTax = $dealerTax;
        $this->dealerHelper = $dealerHelper;
        
        parent::__construct($context);		
	}


	public function execute()
    {
        if (!isset($_FILES['importfile']['tmp_name'])) {
			$this->messageManager->addError(__('Invalid file upload attempt.'));
			$this->_redirect('*/*/tax');
			return;
		}		
		
		$dealer_code = $this->dealerHelper->getLoggedInUser()->getUsername();
		try {		
			$data = $this->csvProcessor->getData($_FILES['importfile']['tmp_name']);
			if (empty($data)) {
				$this->messageManager->addError(__('Uploaded file is blank'));
				$this->_redirect('*/*/inventory');
				return;
			}
			for($i=1; $i<count($data); $i++)
			{
				//var_dump($data[$i]); exit;
				$id = $this->product->getIdBySku($data[$i][1]);
				if($id){
					
					$collection = $this->dealerTax->getCollection()
							->addFieldToFilter('dealer_code',$dealer_code)
							->addFieldToFilter('item_code',$data[$i][1]);							
					if($collection->getSize() > 0){
						foreach($collection as $tax)
						{ 
							$stock = $this->dealerTax->load($tax->getId());
							if(!empty($data[$i][5])){
								$stock->setTax(trim($data[$i][5]));
							}
							if(!empty($data[$i][6])){
								$stock->setCgstTax(trim($data[$i][6]));
							}if(!empty($data[$i][7])){
								$stock->setSgstTax(trim($data[$i][7]));
							}if(!empty($data[$i][8])){
								$stock->setUtgstTax(trim($data[$i][8]));
							}if(!empty($data[$i][9])){
								$stock->setIgstTax(trim($data[$i][9]));
							}
							$stock->save();
						}
					} else {
						if(!empty($data[$i][1])) {
							$catalog = $this->product->load($id);
							 $stock = $this->dealerTax;
							 $stock->setDealerCode($dealer_code)
									->setItemCode(trim($data[$i][1]))
									->setItemDescription(preg_replace( "/\r|\n/", "", strip_tags($catalog->getName())))
									->setItemColor($catalog->getAttributeText('color'))
									->setItemDivisionCode($catalog->getDivisionCode())
									->setTax(trim($data[$i][5]))
									->setCgstTax(trim($data[$i][6]))
									->setSgstTax(trim($data[$i][7]))
									->setUtgstTax(trim($data[$i][8]))
									->setIgstTax(trim($data[$i][9]))
									->save();								
									//echo "<pre>";print_r($stock->getData());exit;
						}
					}
				}
				else
				{
					$this->messageManager->addSuccess(__('Product does not exists %1',$data[$i][1]));
					die();
				}						
			}			
			$this->messageManager->addSuccess(__('File Data Imported Successfully.'));
		} catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
        }

		$this->_redirect('*/*/tax');
		return;	
    }    
}
