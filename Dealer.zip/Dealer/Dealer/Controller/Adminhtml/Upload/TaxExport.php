<?php
namespace FS\Dealer\Controller\Adminhtml\Upload;

class TaxExport extends \Magento\Backend\App\Action
{
	protected $product;
	
	protected $dealerHelper;	

	protected $category;
	
	protected $csvProcessor;
	
	protected $fileFactory;
	
	protected $directoryList;
	
	public function __construct(
		\Magento\Backend\App\Action\Context $context,        
        \Magento\Catalog\Model\Product $product,
        \FS\Dealer\Helper\Data $dealerHelper,        
        \Magento\Catalog\Model\Category $category,
        \Magento\Framework\File\Csv $csvProcessor,
        \FS\Dealer\Model\Dealer\TaxFactory $collectionFactory,
        \Magento\Framework\App\Response\Http\FileFactory $fileFactory,
        \Magento\Framework\App\Filesystem\DirectoryList $directoryList        
	)
	{        
        $this->product = $product;
        $this->dealerHelper = $dealerHelper;        
        $this->category = $category;
        $this->csvProcessor = $csvProcessor;
        $this->fileFactory = $fileFactory;
        $this->directoryList = $directoryList;
         $this->collectionFactory=$collectionFactory;
        parent::__construct($context);		
	}


	public function execute()
    {		
		$data = $this->getRequest()->getPost();
		$catgegoryCollection = $this->category->load($data['category']);
		$prod = $catgegoryCollection->getProductCollection();
		
		$fileName   = 'sample_dealer_tax.csv';
    	$filePath = $this->directoryList->getPath(\Magento\Framework\App\Filesystem\DirectoryList::VAR_DIR)
        	. "/" . $fileName;	
		
		$exportData = $this->getExportData($prod);				
		$this->csvProcessor
    	    ->setDelimiter(',')
        	->setEnclosure('"')
        	->saveData(
            	$filePath,
            	$exportData
        	);
				
		return $this->fileFactory->create(
         $fileName,
         [
             'type' => "filename",
             'value' => $fileName,
             'rm' => true,
         ],
            \Magento\Framework\App\Filesystem\DirectoryList::VAR_DIR,
         'application/octet-stream'
		);
	
    }
    
    protected function getExportData($prod){

		$result [] = ['Dealer_code','sku','Product_Description','color','division_code','KF_Cess','CGST','SGST','UTGST','ITGST'];
		$dealer_code = $this->dealerHelper->getLoggedInUser()->getUsername();
		$roleId=$this->dealerHelper->getLoggedInUserRoleId();

		foreach($prod as $pro) {

			$catalog = $this->product->load($pro->getId());
			//var_dump($catalog->getStatus()); exit;
			if($roleId==3)
			{
				$collection=$this->collectionFactory->create()->getCollection()->addFieldToFilter('main_table.dealer_code',$dealer_code)->addFieldToFilter('item_code',$catalog->getSku())->getFirstItem();
			}
			else
			{
				$collection=$this->collectionFactory->create()->getCollection()->addFieldToFilter('item_code',$catalog->getSku())->getFirstItem();
			}
			// print_r($collection->getSelect()->__toString());
			// die('herre');
			if(!empty($collection))
			{
				if($catalog->getStatus()==1) {
				$result [] = [
					$dealer_code,
					$pro->getSku(),
					preg_replace( "/\r|\n/", "", strip_tags($catalog->getName())),
					$catalog->getAttributeText('color'),
					$catalog->getDivisionCode(),
					'1',
					$collection->getCgstTax(),
					$collection->getSgstTax(),
					$collection->getUtgstTax(),
					$collection->getIgstTax()
				];
					
				/*
				$datarow['dealercode']=$dealer_code;
				$datarow['sku']=$pro->getSku();
				$datarow['desc']=preg_replace( "/\r|\n/", "", strip_tags($catalog->getName()));
				$datarow['color']=$catalog->getAttributeText('color');
				$datarow['division_code']=$catalog->getDivisionCode();
				$datarow['sku']=$pro->getSku();
				$datarow['kfc']='1';
				$datarow['cgst']='';
				$datarow['sgst']='';
				$datarow['utgst']='';
				$datarow['itgst']='';
				
				$line = "";
				$comma = "";
				foreach($datarow as $titlename) {
					$line .= $comma . str_replace(array(','),array(""), $titlename);
					$comma = ",";
				}
				$line .= "\n";
				$inventory_csv_row .=$line;
				*/ 
			}
			}
			
		}
		
		return $result;
	}
}
