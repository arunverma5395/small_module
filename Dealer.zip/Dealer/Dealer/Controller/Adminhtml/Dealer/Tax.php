<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace FS\Dealer\Controller\Adminhtml\Dealer;

abstract class Tax extends \Magento\Backend\App\AbstractAction
{
    /**
     * Authorization level of a basic admin session
     *
     * @see _isAllowed()
     */
    const ADMIN_RESOURCE = 'FS_Dealer::acl_dealer_tax';

    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry;

    /**
     * User model factory
     *
     * @var \FS\Dealer\Model\Dealer\Tax
     */
    protected $_dealerTaxFactory;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\Registry $coreRegistry
     * @param \FS\Dealer\Model\Dealer\Tax $dealerTaxFactory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Registry $coreRegistry,
        \FS\Dealer\Model\Dealer\TaxFactory $dealerTaxFactory
    ) {
        parent::__construct($context);
        $this->_coreRegistry = $coreRegistry;
        $this->_dealerTaxFactory = $dealerTaxFactory;
    }

    /**
     * @return $this
     */
    protected function _initAction()
    {
        $this->_view->loadLayout();
        $this->_setActiveMenu(
            'FS_Dealer::dealer_tax'
        )->_addBreadcrumb(
            __('Dealer Tax'),
            __('Dealer Tax')
        );
        return $this;
    }
}
