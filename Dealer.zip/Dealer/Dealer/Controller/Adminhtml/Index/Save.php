<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace FS\Dealer\Controller\Adminhtml\Index;

use Magento\Framework\App\Action\HttpPostActionInterface as HttpPostActionInterface;
use Magento\Framework\Exception\AuthenticationException;
use Magento\Framework\Exception\State\UserLockedException;
use Magento\Security\Model\SecurityCookie;
use Magento\User\Model\Spi\NotificationExceptionInterface;

/**
 * Save admin user.
 *
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Save extends \FS\Dealer\Controller\Adminhtml\Dealer implements HttpPostActionInterface
{
    /**
     * @var SecurityCookie
     */
    private $securityCookie;

    /**
     * Get security cookie
     *
     * @return SecurityCookie
     * @deprecated 100.1.0
     */
    private function getSecurityCookie()
    {
        if (!($this->securityCookie instanceof SecurityCookie)) {
            return \Magento\Framework\App\ObjectManager::getInstance()->get(SecurityCookie::class);
        } else {
            return $this->securityCookie;
        }
    }

    /**
     * @inheritDoc
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
    public function execute()
    {
        $userId = (int)$this->getRequest()->getParam('user_id');
        $data = $this->getRequest()->getPostValue();
        //echo '<pre>';print_r($data);die;
        if (array_key_exists('form_key', $data)) {
            unset($data['form_key']);
        }
        if (array_key_exists('password', $data) && empty($data['password'])) {
            unset($data['password']);
            unset($data['password_confirmation']);
        }
        if (!$data) {
            $this->_redirect('dealer/*/');
            return;
        }
		
        //@var $model \FS\Dealer\Model\Dealer
        $model = $this->_dealerFactory->create()->load($userId);        
        if ($userId && $model->isObjectNew()) {
            $this->messageManager->addError(__('This user no longer exists.'));
            $this->_redirect('dealer/*/');
            return;
        }
		$model->setData($data);
        //$userRoles = $this->getRequest()->getParam('roles', []);
        //if (count($userRoles)) {
            //$model->setRoleId($userRoles[0]);
        //}

        // @var $currentUser \Magento\User\Model\User 
        //$currentUser = $this->_objectManager->get(\Magento\Backend\Model\Auth\Session::class)->getUser();
        //if ($userId == $currentUser->getId()
          //  && $this->_objectManager->get(\Magento\Framework\Validator\Locale::class)
            //    ->isValid($data['interface_locale'])
        //) {
          //  $this->_objectManager->get(
            //    \Magento\Backend\Model\Locale\Manager::class
           // )->switchBackendInterfaceLocale(
             //   $data['interface_locale']
            //);
        //}
        
        try {			
			//echo "<pre>";print_r($model->getData());exit;
			$model->save();
            $this->_eventManager->dispatch('havells_adminhtml_controller_save_after', ['request' => $this->getRequest(), 'dealer' => $model]);
			$this->messageManager->addSuccess(__('You saved the dealer.'));
            $this->_getSession()->setUserData(false);
            $this->_redirect('dealer/*/');
		} catch (\Magento\Framework\Exception\LocalizedException $e) {
            if ($e->getMessage()) {
                $this->messageManager->addError($e->getMessage());
            }
            $this->redirectToEdit($model, $data);
        }
    }

    /**
     * Redirect to Edit form.
     *
     * @param \FS\Dealer\Model\Dealer $model
     * @param array $data
     * @return void
     */
    protected function redirectToEdit(\FS\Dealer\Model\Dealer $model, array $data)
    {
        $this->_getSession()->setDealerData($data);
        $arguments = $model->getId() ? ['user_id' => $model->getId()] : [];
        $arguments = array_merge($arguments, ['_current' => true, 'active_tab' => '']);
        $this->_redirect('dealer/*/edit', $arguments);
    }
}
