<?php
/**
 *
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace FS\Dealer\Controller\Adminhtml\Index;

use Magento\Framework\Locale\Resolver;

class Edit extends \FS\Dealer\Controller\Adminhtml\Dealer
{
    /**
     * @return void
     */
    public function execute()
    {
        $userId = $this->getRequest()->getParam('user_id');
        /** @var \Magento\User\Model\User $model */
        $model = $this->_dealerFactory->create();

        if ($userId) {
            $model->loadDealer($userId);
            //$model->setDealerId($userId);
            //echo "<pre>";print_r($model->getData());exit;
            if (!$model->getId()) {
                $this->messageManager->addError(__('This user no longer exists.'));
                $this->_redirect('dealer/*/');
                return;
            }
        } else {
            $model->setInterfaceLocale(Resolver::DEFAULT_LOCALE);
        }

        // Restore previously entered form data from session
        $data = $this->_session->getDealerData(true);
        if (!empty($data)) {
            $model->setData($data);
        }

        $this->_coreRegistry->register('dealer_user', $model);

        if (isset($userId)) {
            $breadcrumb = __('Edit User');
        } else {
            $breadcrumb = __('New User');
        }
        $this->_initAction()->_addBreadcrumb($breadcrumb, $breadcrumb);
        $this->_view->getPage()->getConfig()->getTitle()->prepend(__('Users'));
        $this->_view->getPage()->getConfig()->getTitle()->prepend($model->getId() ? $model->getName() : __('New User'));
        $this->_view->renderLayout();
    }
}
