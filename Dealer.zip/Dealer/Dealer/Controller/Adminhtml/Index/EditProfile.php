<?php
/**
 *
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace FS\Dealer\Controller\Adminhtml\Index;

use Magento\Framework\Locale\Resolver;

class EditProfile extends \FS\Dealer\Controller\Adminhtml\Dealer
{
	const DEALER_ADMIN_ROLE_ID = 3;
    /**
     * @return void
     */
    public function execute()
    {
		
		if( $this->_authSession->getUser()->getAclRole() == self::DEALER_ADMIN_ROLE_ID ){
			$userId = $this->_authSession->getUser()->getUserId();
			$this->_redirect('dealer/*/edit', array('user_id'=> $userId));
            return;
		} else {			
			$this->messageManager->addError(__('Please login with your Dealer Username and Password. You are not a valid Dealer.'));
            $this->_redirect('dealer/*/');
            return;			
		}        
    }
}
