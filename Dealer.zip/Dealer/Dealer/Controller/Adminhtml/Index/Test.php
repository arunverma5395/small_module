<?php
namespace FS\Dealer\Controller\Adminhtml\Index;

class Test extends \Magento\Backend\App\Action
{
	protected $_userFactory;
	
	protected $_resourceConnection;

	public function __construct(
		\Magento\Backend\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $resultPageFactory,
		\Magento\Framework\App\ResourceConnection $resourceConnection,
        \Magento\User\Model\User $userFactory
    ) {
		parent::__construct($context);
		$this->resultPageFactory = $resultPageFactory;
		$this->_resourceConnection = $resourceConnection;
        $this->_userFactory = $userFactory;
    }

	public function execute()
	{
		$data['username'] = 'CGO0393';
		$data['firstname'] = 'Manoj';
		$this->createUpdateDealer($data);
	}
	
	public function createUpdateDealer($data){
		$username = $data['username'];
		$model = $this->_userFactory->loadByUsername($username);
		if (!$model->getId()) {
			//Create New Dealer
			
			$model = $this->_userFactory->create();
			$userInfo = [
				'username'  => trim($data['username']),
				'firstname' => $data['firstname'],
				'lastname'  => $data['lastname'],
				'email'     => trim($data['email']),
				'password'  => trim($data['username']),       
				'interface_locale' => 'en_US',
				'is_active' => $data['is_active'] 
			];			
			$model->setRoleId(3);
			$model->save();
		} else {
			//Update Dealer
			
			if(isset($data['firstname']) && !empty($data['firstname'])){
				$model->setFirstName($data['firstname']);
			}
			$model->save();
		}
	}
	
	public function insertDealerInfo($data){
		$connection = $this->_resourceConnection->getConnection();
		$query = "INSERT INTO dealer_info";
		$result = $connection->fetchAll($query);
	}
	
	public function updateDealerInfo($data){
		$connection = $this->_resourceConnection->getConnection();
		$query = "UPDATE dealer_info";
		$result = $connection->fetchAll($query);
	}
}
