<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace FS\Dealer\Block\Adminhtml\Dealer\Upload;

/**
 * User block
 *
 * @api
 * @author     Magento Core Team <core@magentocommerce.com>
 * @since 100.0.2
 */
class Inventory extends \Magento\Backend\Block\Widget\Grid\Container
{
	protected $category;
    /**
     * @var \Magento\User\Model\ResourceModel\User
     */
    protected $_resourceModel;
    
    protected $dealerHelper;

    /**
     * @param \Magento\Backend\Block\Widget\Context $context
     * @param \Magento\User\Model\ResourceModel\User $resourceModel
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Widget\Context $context,
        \FS\Dealer\Model\ResourceModel\Dealer\Tax $resourceModel,
        \Magento\Catalog\Model\Category $category,
        \FS\Dealer\Helper\Data $dealerHelper,        
        array $data = []
    ) {
		$this->_resourceModel = $resourceModel;
		$this->category = $category;
        $this->dealerHelper = $dealerHelper;
        parent::__construct($context, $data);        
    }

    /**
     * Class constructor
     *
     * @return void
     */
    protected function _construct()
    {		
        $this->addData(
            [
                \Magento\Backend\Block\Widget\Container::PARAM_CONTROLLER => 'dealer',
                \Magento\Backend\Block\Widget\Grid\Container::PARAM_BLOCK_GROUP => 'FS_Dealer',
                \Magento\Backend\Block\Widget\Grid\Container::PARAM_BUTTON_NEW => __('Upload Inventory'),
                \Magento\Backend\Block\Widget\Container::PARAM_HEADER_TEXT => __('Dealer'),
            ]
        );
                
        parent::_construct();
        
        $categoryOptions = $this->getSubCategories(2);
        
        if ( $this->dealerHelper->getCurrentUserRoleId() == $this->dealerHelper::DEALER_ROLE_ID ):
			$this->addButton(
				'import',
				[
					'label' => __('Upload Inventory'),
					'on_click' => 'document.getElementById(\'uploadTarget\').click();',
					'class' => 'primary',
					'after_html'    => '<form method="POST" action="'.$this->getUrl('*/*/inventoryupload').'" id="uploadForm" enctype="multipart/form-data">
					<input name="form_key" type="hidden" value="'. $this->getFormKey() .'" />
					<input type="file" name="importfile" style="display:none;" id="uploadTarget"/>
					</form>
					<script type="text/javascript">
					document.getElementById(\'uploadTarget\').addEventListener(\'change\', function(){
						document.getElementById(\'uploadForm\').submit();Element.show(\'loading-mask\');
					}, false);
					</script>',
					'level' => 1
				]
			);
		endif;	
		
		$this->addButton(
			'button1',
			[
				'label'	=>	__('Download Sample file'),
				'id'	=>	'button1',
				'on_click'	=> 'document.getElementById(\'button1\').click();',
				'class' => 'primary',
				'after_html'	=> '<form method="POST" id="uploadForm1" action="'.$this->getUrl('*/*/inventoryexport').'">
				<input name="form_key" type="hidden" value="'. $this->getFormKey() .'" />
				<div class="multiselect">
				    <div class="selectBox">
				      <select id="slt_bx"  style="float: right;width: auto;height: 44px;">
				        <option>Please Select Category</option>
				      </select>
				      <div class="overSelect"></div>
				    </div>
				    <div id="checkboxes" style="display:none;">
				    <label for="SelectAll"><input type="checkbox" id="slctall"/>Select All</label>
					' . $categoryOptions . '
				</div>
				</div>
				</form>',
				'level' => 1
			]
		);
        //$this->_addNewButton();
    }
    
    protected function getSubCategories($catId){		
		$category = $this->category->load($catId);
		$subCats = $category->getChildrenCategories();
		
		$optionVal='';
		foreach ($subCats as $subcat) {
			$option = '<label for="Havells - '.$subcat->getName().'"><input name="slctall" type="checkbox" class="slctall" value="'.$subcat->getId().'" /> Havells - '.$subcat->getName().'</label>';
			$optionVal=$option.$optionVal;			
		}
		return $optionVal;
	}
}
