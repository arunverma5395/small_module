<?php
namespace FS\Dealer\Block\Adminhtml\Dealer\Accept;

use Magento\Backend\Block\Template;
use Magento\Backend\Model\Auth\Session;
use FS\Dealer\Model\Dealer\Tax\Tnc as TncModel;

class Tnc extends Template
{
    /**
     *
     * @var Session
     */
    protected $authSession;

    /**
     * @param Template\Context $context
     * @param array $data
     */
    public function __construct(
        Template\Context $context,
        Session $authSession,
        TncModel $tncModel,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->authSession = $authSession;
        $this->tncModel = $tncModel;
    }

    public function getCurrentUser()
    {
        return $this->authSession->getUser();
    }

    public function getTaxTncInfo()
    {
        $dealerCode = $this->authSession->getUser()->getUsername();
        return $this->tncModel->load($dealerCode, 'dealer_code');
    }
}
