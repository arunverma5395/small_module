<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace FS\Dealer\Block\Adminhtml\Dealer\Edit\Tab;

use Magento\Framework\App\ObjectManager;
use Magento\Framework\Locale\OptionInterface;

/**
 * Cms page edit form main tab
 *
 * @SuppressWarnings(PHPMD.DepthOfInheritance)
 */
class Profile extends \Magento\Backend\Block\Widget\Form\Generic
{
    const CURRENT_USER_PASSWORD_FIELD = 'current_password';

    /**
     * @var \Magento\Backend\Model\Auth\Session
     */
    protected $_authSession;

    /**
     * @var \Magento\Framework\Locale\ListsInterface
     */
    protected $_LocaleLists;

    /**
     * Operates with deployed locales.
     *
     * @var OptionInterface
     */
    private $deployedLocales;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Backend\Model\Auth\Session $authSession
     * @param \Magento\Framework\Locale\ListsInterface $localeLists
     * @param array $data
     * @param OptionInterface $deployedLocales Operates with deployed locales.
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Backend\Model\Auth\Session $authSession,
        \Magento\Framework\Locale\ListsInterface $localeLists,
        array $data = [],
        OptionInterface $deployedLocales = null
    ) {
        $this->_authSession = $authSession;
        $this->_LocaleLists = $localeLists;
        $this->deployedLocales = $deployedLocales
            ?: ObjectManager::getInstance()->get(OptionInterface::class);
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Prepare form fields
     *
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     * @return \Magento\Backend\Block\Widg et\Form
     */
    protected function _prepareForm()
    {
        /** @var $model \FS\Dealer\Model\Dealer */
        $model = $this->_coreRegistry->registry('dealer_user');

        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();
        $form->setHtmlIdPrefix('dealer_');

        $baseFieldset = $form->addFieldset('base_fieldset', ['legend' => __('Profile')]);

        if ($model->getUserId()) {
            $baseFieldset->addField('user_id', 'hidden', ['name' => 'user_id']);
        } else {
            if (!$model->hasData('is_active')) {
                $model->setIsActive(1);
            }
        }
        
        if( $this->_authSession->getUser()->getAclRole() == 1 ){
			$statusEnableDisable = 'enabled';
		} else {
			$statusEnableDisable = 'disabled';			
		}

		$baseFieldset->addField(
            'username',
            'text',
            [
                'name' => 'username',
                'label' => __('Dealer Code'),
                'id' => 'username',
                'title' => __('Dealer Code'),
                'required' => true,
                'class' => 'required-entry disabled',
            ]
        );
        
        $baseFieldset->addField(
            'firm_name',
            'text',
            [
                'name' => 'firm_name',
                'label' => __('Firm Name'),
                'id' => 'firm_name',
                'title' => __('Firm Name'),
                'required' => true,
                'class' => $statusEnableDisable,
            ]
        );
        
        $baseFieldset->addField(
            'email',
            'text',
            [
                'name' => 'email',
                'label' => __('Email'),
                'id' => 'customer_email',
                'title' => __('User Email'),
                'class' => 'required-entry validate-email ' . $statusEnableDisable,
                'required' => true
            ]
        );

        $baseFieldset->addField(
            'mobile',
            'text',
            [
                'name' => 'mobile',
                'label' => __('Registered Mobile'),
                'id' => 'firstname',
                'title' => __('Registered Mobile'),
                'required' => false,
                'class' => $statusEnableDisable,
            ]
        );
        
        $baseFieldset->addField(
            'tin_no',
            'text',
            [
                'name' => 'tin_no',
                'label' => __('VAT No/ TIN No'),
                'id' => 'tin_no',
                'title' => __('VAT No/ TIN No'),
                'required' => false,
                'class' => $statusEnableDisable,
            ]
        );
        
        $baseFieldset->addField(
            'gs_tin_no',
            'text',
            [
                'name' => 'gs_tin_no',
                'label' => __('GSTIN No'),
                'id' => 'gs_tin_no',
                'title' => __('GSTIN No'),
                'required' => true,
                'class' => $statusEnableDisable,
            ]
        );
        
        $baseFieldset->addField(
            'pan',
            'text',
            [
                'name' => 'pan',
                'label' => __('PAN No'),
                'id' => 'pan',
                'title' => __('PAN No'),
                'required' => true,
                'class' => $statusEnableDisable,
            ]
        );
        
        $baseFieldset->addField(
            'cin_no',
            'text',
            [
                'name' => 'cin_no',
                'label' => __('CIN No'),
                'id' => 'cin_no',
                'title' => __('CIN No'),
                'required' => false,
                'class' => $statusEnableDisable,
            ]
        );
        
        $baseFieldset->addField(
            'financial_code',
            'text',
            [
                'name' => 'financial_code',
                'label' => __('Financial Code'),
                'id' => 'financial_code',
                'title' => __('Financial Code'),
                'required' => false,
                'class' => $statusEnableDisable,
            ]
        );
        
        $baseFieldset->addField(
            'address1',
            'text',
            [
                'name' => 'address1',
                'label' => __('Address 1'),
                'id' => 'address1',
                'title' => __('Address 1'),
                'required' => false,
                'class' => $statusEnableDisable,
            ]
        );
        
        $baseFieldset->addField(
            'address2',
            'text',
            [
                'name' => 'address2',
                'label' => __('Address 2'),
                'id' => 'address2',
                'title' => __('Address 2'),
                'required' => false,
                'class' => $statusEnableDisable,
            ]
        );

		$baseFieldset->addField(
            'city',
            'text',
            [
                'name' => 'city',
                'label' => __('City'),
                'id' => 'city',
                'title' => __('City'),
                'required' => false,
                'class' => $statusEnableDisable,
            ]
        );

        $baseFieldset->addField(
            'state_code',
            'text',
            [
                'name' => 'state_code',
                'label' => __('GST State Code'),
                'id' => 'state_code',
                'title' => __('GST State Code'),
                'required' => false,
                'class' => $statusEnableDisable,
            ]
        );
        
        $baseFieldset->addField(
            'state',
            'text',
            [
                'name' => 'state',
                'label' => __('State'),
                'id' => 'state',
                'title' => __('State'),
                'required' => false,
                'class' => $statusEnableDisable,
            ]
        );
        
        $baseFieldset->addField(
            'pin',
            'text',
            [
                'name' => 'pin',
                'label' => __('Pincode'),
                'id' => 'pin',
                'title' => __('Pincode'),
                'required' => false,
                'class' => $statusEnableDisable,
            ]
        );
        
        //if ($this->_authSession->getUser()->getId() != $model->getUserId()) {
            $baseFieldset->addField(
                'is_active',
                'select',
                [
                    'name' => 'is_active',
                    'label' => __('This account is'),
                    'id' => 'is_active',
                    'title' => __('Account Status'),
                    'class' => 'input-select',
                    'options' => ['1' => __('Active'), '0' => __('Inactive')]
                ]
            );
        //}        

        $data = $model->getData();
        unset($data['password']);
        unset($data[self::CURRENT_USER_PASSWORD_FIELD]);
        $form->setValues($data);

        $this->setForm($form);

        return parent::_prepareForm();
    }

    /**
     * Add password input fields
     *
     * @param \Magento\Framework\Data\Form\Element\Fieldset $fieldset
     * @param string $passwordLabel
     * @param string $confirmationLabel
     * @param bool $isRequired
     * @return void
     */
    /*
    protected function _addPasswordFields(
        \Magento\Framework\Data\Form\Element\Fieldset $fieldset,
        $passwordLabel,
        $confirmationLabel,
        $isRequired = false
    ) {
        $requiredFieldClass = $isRequired ? ' required-entry' : '';
        $fieldset->addField(
            'password',
            'password',
            [
                'name' => 'password',
                'label' => $passwordLabel,
                'id' => 'customer_pass',
                'title' => $passwordLabel,
                'class' => 'input-text validate-admin-password' . $requiredFieldClass,
                'required' => $isRequired
            ]
        );
        $fieldset->addField(
            'confirmation',
            'password',
            [
                'name' => 'password_confirmation',
                'label' => $confirmationLabel,
                'id' => 'confirmation',
                'title' => $confirmationLabel,
                'class' => 'input-text validate-cpassword' . $requiredFieldClass,
                'required' => $isRequired
            ]
        );
    }*/
}
