<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace FS\Dealer\Block\Adminhtml\Dealer\Edit;

/**
 * User page left menu
 *
 * @api
 * @author      Magento Core Team <core@magentocommerce.com>
 * @since 100.0.2
 */
class Tabs extends \Magento\Backend\Block\Widget\Tabs
{
    /**
     * Class constructor
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('page_tabs');
        $this->setDestElementId('edit_form');
        $this->setTitle(__('Dealer Information'));
    }

    /**
     * @return $this
     */
    protected function _beforeToHtml()
    {
        $this->addTab(
            'profile_section',
            [
                'label' => __('Profile'),
                'title' => __('Profile'),
                'content' => $this->getLayout()->createBlock(
					\FS\Dealer\Block\Adminhtml\Dealer\Edit\Tab\Profile::class
				)->toHtml(),
                'active' => true
            ]
        );
		/**/
        $this->addTab(
            'contact_section',
            [
                'label' => __('Contact Information'),
                'title' => __('Contact Information'),
                'content' => $this->getLayout()->createBlock(
                    \FS\Dealer\Block\Adminhtml\Dealer\Edit\Tab\Contact::class
                )->toHtml()
            ]
        );
        
        $this->addTab(
            'billing_section',
            [
                'label' => __('Billing Information'),
                'title' => __('Billing Information'),
                'content' => $this->getLayout()->createBlock(
					\FS\Dealer\Block\Adminhtml\Dealer\Edit\Tab\Billing::class
				)->toHtml()
            ]
        );
        
        $this->addTab(
            'password_section',
            [
                'label' => __('Change Password'),
                'title' => __('Change Password'),
                'content' => $this->getLayout()->createBlock(
					\FS\Dealer\Block\Adminhtml\Dealer\Edit\Tab\Password::class
				)->toHtml()
            ]
        );
        
        $this->addTab(
            'courier_section',
            [
                'label' => __('Courier Credentials'),
                'title' => __('Courier Credentials'),
                'content' => $this->getLayout()->createBlock(
					\FS\Dealer\Block\Adminhtml\Dealer\Edit\Tab\Courier::class
				)->toHtml()
            ]
        );
        
        $this->addTab(
            'region_section',
            [
                'label' => __('Region Mapping'),
                'title' => __('Region Mapping'),
                'content' => $this->getLayout()->createBlock(
					\FS\Dealer\Block\Adminhtml\Dealer\Edit\Tab\Region::class
				)->toHtml()
            ]
        );
        /**/
        return parent::_beforeToHtml();
    }
}
