# FS\Dealer
![php 7.2+][mysql 8.0+]

## About Dealer

Dealer Module is having below contents:
	ADMIN
		- Dealer List
		- Dealer Data
		- Edit Dealer Profile
		- Upload Inventory
		- Upload Tax

## Getting Started

* **You Need to Move old Tables alredy created in Database ** -
* **[TABLES]** 
dealer_info
+--------------------------+--------------+------+-----+---------+-------+
| Field                    | Type         | Null | Key | Default | Extra |
+--------------------------+--------------+------+-----+---------+-------+
| entity_id                | int          | NO   |     | 0       |       |
| dealer_id                | int          | NO   |     | NULL    |       |
| dealer_code              | varchar(200) | YES  |     | NULL    |       |
| firm_name                | varchar(200) | YES  |     | NULL    |       |
| pan                      | varchar(25)  | YES  |     | NULL    |       |
| mobile                   | varchar(15)  | YES  |     | NULL    |       |
| cin_no                   | varchar(50)  | YES  |     | NULL    |       |
| address1                 | text         | YES  |     | NULL    |       |
| address2                 | text         | YES  |     | NULL    |       |
| tin_no                   | varchar(50)  | YES  |     | NULL    |       |
| cst_no                   | varchar(50)  | YES  |     | NULL    |       |
| pin                      | varchar(200) | YES  |     | NULL    |       |
| contact_first_name       | varchar(45)  | YES  |     | NULL    |       |
| contact_last_name        | varchar(45)  | YES  |     | NULL    |       |
| contact_mobile           | varchar(15)  | YES  |     | NULL    |       |
| billing_range            | varchar(100) | YES  |     | NULL    |       |
| last_generated_bill      | varchar(100) | YES  |     | NULL    |       |
| financial_code           | varchar(50)  | YES  |     | NULL    |       |
| surface_clientid         | varchar(50)  | YES  |     | NULL    |       |
| surface_licensekey       | varchar(100) | YES  |     | NULL    |       |
| express_clientid         | varchar(50)  | YES  |     | NULL    |       |
| express_licensekey       | varchar(100) | YES  |     | NULL    |       |
| gs_tin_no                | varchar(30)  | YES  |     | NULL    |       |
| state                    | varchar(25)  | YES  |     | NULL    |       |
| state_code               | varchar(25)  | YES  |     | NULL    |       |
| state_name               | varchar(25)  | NO   |     | NULL    |       |
| kam_email                | varchar(255) | YES  |     | NULL    |       |
| kam_name                 | varchar(255) | YES  |     | NULL    |       |
| kam_mobile               | varchar(255) | YES  |     | NULL    |       |
| kam_pernr                | varchar(255) | YES  |     | NULL    |       |
| shiprocket_user_email_id | varchar(255) | YES  |     | NULL    |       |
| shiprocket_user_password | varchar(255) | YES  |     | NULL    |       |
+--------------------------+--------------+------+-----+---------+-------+
                            
dealer_inventry                         
+--------------------+--------------+------+-----+---------+-------+
| Field              | Type         | Null | Key | Default | Extra |
+--------------------+--------------+------+-----+---------+-------+
| entity_id          | int          | NO   |     | 0       |       |
| dealer_code        | varchar(45)  | YES  |     | NULL    |       |
| dealer_id          | int          | YES  |     | NULL    |       |
| sku                | varchar(45)  | YES  |     | NULL    |       |
| item_description   | varchar(100) | YES  |     | NULL    |       |
| item_division_code | varchar(45)  | YES  |     | NULL    |       |
| item_color         | varchar(45)  | YES  |     | NULL    |       |
| opening_stock      | int          | YES  |     | NULL    |       |
| inventry           | int          | YES  |     | NULL    |       |
| threshold          | int          | YES  |     | NULL    |       |
| internal_order     | int          | NO   |     | 0       |       |
+--------------------+--------------+------+-----+---------+-------+
dealer_tax                              
+--------------------+---------------+------+-----+---------+-------+
| Field              | Type          | Null | Key | Default | Extra |
+--------------------+---------------+------+-----+---------+-------+
| entity_id          | int           | NO   | PRI | 0       |       |
| dealer_code        | varchar(30)   | YES  |     | NULL    |       |
| mpg_code           | varchar(20)   | YES  |     | NULL    |       |
| item_code          | varchar(50)   | YES  |     | NULL    |       |
| item_description   | varchar(100)  | YES  |     | NULL    |       |
| item_division_code | varchar(45)   | YES  |     | NULL    |       |
| item_color         | varchar(45)   | YES  |     | NULL    |       |
| tax                | decimal(8,3)  | YES  |     | NULL    |       |
| cgst_tax           | decimal(12,4) | YES  |     | NULL    |       |
| sgst_tax           | decimal(12,4) | YES  |     | NULL    |       |
| igst_tax           | decimal(12,4) | YES  |     | NULL    |       |
| utgst_tax          | decimal(12,4) | YES  |     | NULL    |       |
| havdealer_taxcol   | varchar(45)   | YES  |     | NULL    |       |
+--------------------+---------------+------+-----+---------+-------+
dealer_tax_entity                       
+-----------+--------------+------+-----+---------+-------+
| Field     | Type         | Null | Key | Default | Extra |
+-----------+--------------+------+-----+---------+-------+
| entity_id | int          | NO   |     | 0       |       |
| mpg_code  | varchar(20)  | YES  |     | NULL    |       |
| desc      | varchar(100) | YES  |     | NULL    |       |
| tax       | decimal(8,2) | YES  |     | NULL    |       |
+-----------+--------------+------+-----+---------+-------+
pin_division_dealer_data
+-------------------+-------------+------+-----+---------+-------+
| Field             | Type        | Null | Key | Default | Extra |
+-------------------+-------------+------+-----+---------+-------+
| entity_id         | int         | NO   |     | 0       |       |
| pincode           | int         | YES  |     | NULL    |       |
| division          | varchar(45) | YES  |     | NULL    |       |
| material_group    | varchar(45) | YES  |     | NULL    |       |
| partner_type      | varchar(45) | YES  |     | NULL    |       |
| partner_code      | varchar(45) | YES  |     | NULL    |       |
| sap_division_code | int         | YES  |     | NULL    |       |
| mdm_partner_code  | varchar(45) | YES  |     | NULL    |       |
| eff_frmdt         | datetime    | YES  |     | NULL    |       |
| eff_todt          | datetime    | YES  |     | NULL    |       |
| priority          | int         | YES  |     | NULL    |       |
| active            | tinyint(1)  | YES  |     | NULL    |       |
+-------------------+-------------+------+-----+---------+-------+
