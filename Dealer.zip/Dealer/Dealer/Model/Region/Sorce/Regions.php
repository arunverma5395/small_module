<?php
namespace Havells\DealerGraphQl\Model\Resolver;

use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;
use Magento\Framework\GraphQl\Exception\GraphQlInputException;

class AvailabilityResolver implements ResolverInterface
{
    /**
     * @var \Havells\Dealer\Model\Availability
     */
    protected $productAvailabilityChecker;

    /**
     * @param \Havells\Dealer\Model\Availability $productAvailabilityChecker
     */
    public function __construct(
        \Havells\Dealer\Model\Availability $productAvailabilityChecker
    ) {
        $this->productAvailabilityChecker = $productAvailabilityChecker;
    }

    /**
     * @inheritdoc
     */
    public function resolve(
        Field $field,
        $context,
        ResolveInfo $info,
        array $value = null,
        array $args = null
    ) {
        if (empty($args['pincode'])) {
            throw new GraphQlInputException(__('Specify the pincode.'));
        }

        if (empty($args['sku'])) {
            throw new GraphQlInputException(__('Specify the sku.'));
        }

        if (empty($args['qty'])) {
            throw new GraphQlInputException(__('Specify the quantity.'));
        }
        
        $items[] = [
            'sku' => $args['sku'],
            'qty' => $args['qty']
        ];
        try {
            $this->productAvailabilityChecker->setPincode($args['pincode'])->setItems($items)->checkProductsAvailability();
            return ['status' => true, 'message' => "Congratulations! Shipping is Available for your location"];
            
        } catch (Exception $e) {
            return ['status' => false, 'message' => "Sorry! Shipping is not Available for your location"];   
        }
        
    }
}
