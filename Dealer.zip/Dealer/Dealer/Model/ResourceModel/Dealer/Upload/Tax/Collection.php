<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace FS\Dealer\Model\ResourceModel\Dealer\Upload\Tax;

/**
 * Admin user collection
 *
 * @api
 * @since 100.0.2
 */
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(\FS\Dealer\Model\Dealer\Upload\Tax::class, \FS\Dealer\Model\ResourceModel\Dealer\Upload\Tax::class);
    }

    /**
     * Collection Init Select
     *
     * @return $this
     * @since 101.1.0
     */
    protected function _initSelect()
    {
        parent::_initSelect();
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $extensionUser = $objectManager->get('Magento\Backend\Model\Auth\Session')->getUser();
        // print_r($extensionUser->getData());
        // die('here');
        $username=$extensionUser->getUsername();
        $this->getSelect()
        ->join(
            ['dealer_info' => $this->getTable('dealer_info')],
            'main_table.dealer_code = dealer_info.dealer_code',
            ['state'=>'dealer_info.state','firm_name'=>'dealer_info.firm_name']
        );
        if($extensionUser->getAclRole()==3)
        {
            $this->getSelect()->where(
            "dealer_info.dealer_code = "."'$username'" //NOTE: parent_id = 3 tends to "Dealer" Role
            );
        }
        // print_r($this->getSelect()->__toString());
        // die();
        
    }    
}
