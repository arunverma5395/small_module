<?php
namespace FS\Dealer\Model\ResourceModel\Dealer\Tax;

class Tnc extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Define main table
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('dealer_tax_tnc', 'entity_id');
    }
}
