<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace FS\Dealer\Model\ResourceModel\Dealer\Tax;

/**
 * Admin user collection
 *
 * @api
 * @since 100.0.2
 */
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(\FS\Dealer\Model\Dealer\Tax::class, \FS\Dealer\Model\ResourceModel\Dealer\Tax::class);
    }

    /**
     * Collection Init Select
     *
     * @return $this
     * @since 101.1.0
     */
    protected function _initSelect()
    {
        parent::_initSelect();
       $this->getSelect();

        

   //      $this->getSelect()->joinLeft(
   //          ['dealer_tax_entity' => $this->getTable('dealer_tax_entity')],
   //          'main_table.mpg_code = dealer_tax_entity.entity_id',
   //          ['desc', 'dealer_tax_entity.desc']
   //      );
        
   //      ->where(
			// "{$table}.parent_id = 3" //NOTE: parent_id = 3 tends to "Dealer" Role
   //      );
   //      print_r($this->getSelect()->__toString());
   //      die();
    }    
}
