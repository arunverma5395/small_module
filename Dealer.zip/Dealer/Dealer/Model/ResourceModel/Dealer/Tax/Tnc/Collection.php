<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace FS\Dealer\Model\ResourceModel\Dealer\Tax\Tnc;

/**
 * Admin user collection
 *
 * @api
 * @since 100.0.2
 */
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(\FS\Dealer\Model\Dealer\Tax\Tnc::class, \FS\Dealer\Model\ResourceModel\Dealer\Tax\Tnc::class);
    }   
}
