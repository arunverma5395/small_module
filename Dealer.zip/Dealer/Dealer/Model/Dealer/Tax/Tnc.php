<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace FS\Dealer\Model\Dealer\Tax;

use Magento\Framework\Model\AbstractModel;

class Tnc extends AbstractModel
{
    /**
     * Initialize user model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(\FS\Dealer\Model\ResourceModel\Dealer\Tax\Tnc::class);
    }
}
