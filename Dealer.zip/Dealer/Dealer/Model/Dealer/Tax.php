<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace FS\Dealer\Model\Dealer;

use Magento\Framework\Model\AbstractModel;

class Tax extends AbstractModel
{
    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Model\ResourceModel\AbstractResource $resource
     * @param \Magento\Framework\Data\Collection\AbstractDb $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Havells\Directory\Model\Gst\State $gstState,
        \Havells\Dealer\Model\Dealer $dealer,
        \Havells\Delhivery\Model\Pincode $pincode,
        \Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
        \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        $this->gstState=$gstState;
        $this->dealer=$dealer;
        $this->pincode=$pincode;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);        
    }

    /**
     * Initialize user model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(\FS\Dealer\Model\ResourceModel\Dealer\Tax::class);
    }
    
    /**
     * @inheritDoc
     */
    public function getFirstName()
    {
        return $this->_getData('firstname');
    }

    /**
     * @inheritDoc
     */
    public function setFirstName($firstName)
    {
        return $this->setData('firstname', $firstName);
    }  

    public function getTotalTax($order, $_item)
    {
        /***************** GST Calculation ************************/
            $taxInfo = $this->getProductGSTTax($_item->getDealerId(),$_item->getSku(),'');
            
            $DealerStateCode = $this->dealer->load($_item->getDealerId(),"dealer_id")->getStateCode();
            $DealerState=$this->gstState->getCollection->addFieldToFilter('gst_st_code',$DealerStateCode)->getFirstItem()->getDmState();
    
            
            $taxType = $taxType = '';
            if($order->getBillingAddress()->getCountryId() == 'IN'){
                $customerPin = $order->getShippingAddress()->getPostcode();
                $taxType = 'India';
            }else{
                $customerPin = $order->getShippingAddress()->getPostcode();
                $taxType = 'abroad';
            }
            $UTArr=array("Chandigarh"=>"CH","Andman Nicobar"=>"AN","Lakshadweep"=>"LK","Delhi"=>"DL","Dadra and Nagar"=>"DNH","Pondicherry"=>"PU","Daman and Diu"=>"GJ");
            $CustState = $this->pincode->getCollection()->addFieldToFilter("pin",$customerPin)->getFirstItem()->getStateCode();
            
            if(strtolower($taxType)=='india'){
                
                
                if(strtolower($CustState) == strtolower($DealerState)){
                    
                    if(in_array($CustState,$UTArr) || in_array($CustState,$UTArr)){
                        
                        $total_percent['UTGST'] = $taxInfo['0']['utgst_tax'];
                        $total_percent['Amount'] += $taxInfo['0']['utgst_tax'];
                        
                        $total_percent['CGST'] = $taxInfo['0']['cgst_tax'];
                        $total_percent['Amount'] += $taxInfo['0']['cgst_tax'];
                        
                    } else if(strtolower($CustState) == "kl" && strtolower($DealerState) == "kl") {
                        $total_percent['SGST'] = $taxInfo['0']['sgst_tax'];
                        $total_percent['Amount'] += $taxInfo['0']['sgst_tax'];
                        
                        $total_percent['CGST'] = $taxInfo['0']['cgst_tax'];
                        $total_percent['Amount'] += $taxInfo['0']['cgst_tax'];

                        $total_percent['KFCESS'] = 1;
                        $total_percent['Amount'] += 1;
                    } else{
                        $total_percent['SGST'] = $taxInfo['0']['sgst_tax'];
                        $total_percent['Amount'] += $taxInfo['0']['sgst_tax'];
                        
                        $total_percent['CGST'] = $taxInfo['0']['cgst_tax'];
                        $total_percent['Amount'] += $taxInfo['0']['cgst_tax'];
                    }
                }else{
                    $total_percent['IGST'] = $taxInfo['0']['igst_tax'];
                    $total_percent['Amount'] += $taxInfo['0']['igst_tax'];
                }
            }else{
                $total_percent['IGST'] = $taxInfo['0']['igst_tax'];
                $total_percent['Amount'] += $taxInfo['0']['igst_tax'];
            }
        return $total_percent;
    }


    public function getOrderItemTax($_item){

        $itemPrice = ($_item->getBasePrice()* ($_item->getQty()*1)) - $_item->getDiscountAmount();
        $order = $_item->getOrder();
        $total_percent = $this->getTotalTax($order,$_item);
        $itemTotalTax=$CGST_Amount=$SGST_Amount=$UTGST_Amount=$IGST_Amount=$KLCess_Amount=0;
        $tax = [];
        if(!empty($total_percent['Amount'])){
            $totalValue=$_item->getRowTotal()-$_item->getDiscountAmount();
            $basePrice= ($totalValue/((100+$total_percent['Amount'])/100));
            
            foreach($total_percent as $taxType => $taxPercent){
                if($taxType == 'CGST'){
                    $CGST_Amount=(($basePrice*$taxPercent)/100);
                }
                if($taxType == 'SGST'){
                    $SGST_Amount=(($basePrice*$taxPercent)/100);
                }
                if($taxType == 'UTGST'){
                    $UTGST_Amount=(($basePrice*$taxPercent)/100);
                }
                if($taxType == 'IGST'){
                    $IGST_Amount=(($basePrice*$taxPercent)/100);
                }
                if($taxType == 'KFCESS'){
                    $KLCess_Amount=(($basePrice*$taxPercent)/100);
                }
            }
            $itemTotalTax = $CGST_Amount+$SGST_Amount+$UTGST_Amount+$IGST_Amount+$KLCess_Amount;

            $tax['taxable_amount'] = $basePrice;
            $tax['taxable_amount'] = $basePrice;
            $tax['tax_rate'] = $total_percent['Amount'];
            $tax['cgst'] = $CGST_Amount;
            $tax['sgst'] = $SGST_Amount;
            $tax['utgst'] = $UTGST_Amount;
            $tax['igst'] = $IGST_Amount;
            $tax['kfcess'] = $KLCess_Amount;
            $tax['total_tax'] = $itemTotalTax;
        }
        return $tax;
    }
}
