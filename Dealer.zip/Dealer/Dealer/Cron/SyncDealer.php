<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace FS\Dealer\Cron;

use Magento\User\Model\User;
use FS\Dealer\Model\Dealer;

/**
 * Find deprecated frontend actions (@see \Magento\Catalog\Api\Data\ProductFrontendActionInterface)
 * Frontend actions deprecates by lifetime.
 * For each scope we have own lifetime.
 */
class SyncDealer
{
    public function __construct(
        \Magento\User\Model\UserFactory $userFactory
    ) {
        $this->_userFactory = $userFactory;
    }

    public function execute()
    {
		try{
			$api_flag=true;
			$error=array();
			$origin=Mage::getStoreConfig('general/newgroup/SAP_origin');
			$url = Mage::getStoreConfig('general/newgroup/sap_url').'ecomm_distributor';
			$parmeters = array("IM_FLAG"=>"R","bapiname"=>"ZBAPI_ECOM_DISTRIBUTOR");
			$post_string = implode('&',array_map(function ($v, $k) { return $k . '=' . $v; },$parmeters,array_keys($parmeters)) );
			$getData=http_build_query($parmeters);
			$url=$url.'?'.$getData;
			//$this->headers = array("Content-type: application/x-www-form-urlencoded"); 
			$ch = curl_init();
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); 
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_TIMEOUT, 5000);
            //curl_setopt($ch, CURLOPT_POST, true);
            //curl_setopt($ch, CURLOPT_POSTFIELDS, $post_string); // the SOAP request
            curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-type: application/x-www-form-urlencoded","Origin: $origin"));			
			$response = curl_exec($ch);
			if(curl_errno($ch)){	
				$api_flag=false;
				mail($this->sender.", ".$this->sender1,"Havells - Live : SAP Api dealer not working",curl_strerror(curl_errno($ch)),$this->headers);
				throw new Exception('SAP Api dealer not working '.curl_error($ch));
			}
			$resp = json_decode($response,true);  
			$file = fopen($this->basepath."cron_logs/Dealer-update-log_".date("Y-m-d").".txt","a+");
					fwrite($file,"\n=============== date=".date("Y-m-d, H:i:s")." \n <br>=========================\n");
					fwrite($file,$response);

			$role = 5;
			foreach($resp['LT_DISTRIBUTOR'] as $key => $dealer){
				if($key == 0){
					continue;
				}
				
				if(empty($dealer['EMAILID']))
				{
					$error[]=array("KEY1"=>$dealer['KUNNR'],"ERROR"=>"Email can not be empty");
					continue;
				}
				if(empty($dealer['NAME1']))
				{
					$error[]=array("KEY1"=>$dealer['KUNNR'],"ERROR"=>"Firm Name can not be empty");
					continue;
				}
				/*if(empty($dealer['J_1ILSTNO']))
				{
					$error[]=array("KEY1"=>$dealer['KUNNR'],"ERROR"=>"Tin no. can not be empty");
					continue;
				}*/
				if(empty($dealer['STCD3']))
				{
					$error[]=array("KEY1"=>$dealer['KUNNR'],"ERROR"=>"GSTin no. can not be empty");
					continue;
				}
				/* if(empty($dealer['CIN'])) 
				{
					$error[]=array("KEY1"=>$dealer['KUNNR'],"ERROR"=>"CIN no. can not be empty");
					continue;
				} */
				if(empty($dealer['POST_CODE']))
				{
					$error[]=array("KEY1"=>$dealer['KUNNR'],"ERROR"=>"PostCode can not be empty");
					continue;
				}
				if(empty($dealer['GST_ST_CODE']))
				{
					$error[]=array("KEY1"=>$dealer['KUNNR'],"ERROR"=>"GST state code can not be empty");
					continue;
				}
				if(empty($dealer['GST_ST_NAME']))
				{
					$error[]=array("KEY1"=>$dealer['KUNNR'],"ERROR"=>"GST State name can not be empty");
					continue;
				}
				if(empty($dealer['J_1IPANNO']))
				{
					$error[]=array("KEY1"=>$dealer['KUNNR'],"ERROR"=>"Pan no. can not be empty");
					continue;
				}
				try{
				$user = Mage::getModel('admin/user');
				$userId = $user->load($dealer['KUNNR'], 'username')->getId();
				$userEmailId='';
				if(!empty($dealer['EMAILID'])){
					$userEmailId = $user->load($dealer['EMAILID'], 'email')->getId();
				}
				if(empty($userId) && empty($userEmailId) && !empty($dealer['EMAILID'])){
					$user->setData(array(
					'username'  => $dealer['KUNNR'],
					'firstname' => $dealer['NAMEV'],
					'lastname'    => $dealer['LNAME'],
					'email'     => $dealer['EMAILID'],
					'password'  =>$dealer['KUNNR'],
					'is_active' => 0
					))->save(); 
									
					$user->setRoleIds(array($role))->setRoleUserId($user->getId())->saveRelations();
					$lastDealerCode = $dealer['KUNNR'];
				}
				if(!empty($user->getId())){
					$userInfo = Mage::getModel('dealer/info')->load($user->getId(), 'dealer_id');
						if(empty($userInfo->getId())) {
							$userInfo->setDealerId($user->getId())->setDealerCode($dealer['KUNNR']);
						} 
						$userInfo->setDealerId($user->getId())
							->setFirm_name($dealer['NAME1'])
							->setTinNo($dealer['J_1ILSTNO'])
							->setGsTinNo($dealer['STCD3'])
							->setAddress1($dealer['ADDRESS1'])
							->setAddress2($dealer['ADDRESS2'])
							->setCstNo($dealer['J_1ICSTNO'])
							->setMobile($dealer['PHONE_NO'])
							->setCity($dealer['VKBUR_DESC'])
							->setState($dealer['GST_ST_NAME'])
							->setPin($dealer['POST_CODE'])
							->setCinNo($dealer['CIN'])
							->setStateCode($dealer['GST_ST_CODE'])
							->setStateName($dealer['GST_ST_NAME'])
							->setContactFirstName($dealer['NAMEV'])
							->setContactLastName($dealer['LNAME'])
							->setPan($dealer['J_1IPANNO'])
							->setKamPernr($dealer['KAM_PERNR'])
							->setKamName($dealer['KAM_NAME'])
							->setKamMobile($dealer['KAM_MOBILE'])
							->setKamEmail($dealer['KAM_EMAIL']);
						$userInfo->save();  
				}
				$file = fopen($this->basepath."cron_logs/dealer-login.txt","a+");
				fwrite($file,"User ID = ".$user->getUserId()."--".$dealer['KUNNR']."---".date("Y-M-d, H:i:s")."\n");
				fclose($file);
				unset($user);
				unset($userInfo);
				}catch(Exception $e){
					//$api_flag=false;
					continue;   
				}
			}
			curl_close($ch);
		}catch (Exception $e) {
				if(isset($userInfo)){
					$message=$userInfo->getDealerCode().'='.$e->getMessage();
				}else{
					$message=$e->getMessage();
				}
				$api_flag=false;
				mail($this->sender,"Havells - Live : Error in SAP dealer Api",$message,$this->headers);
		}
		//echo "dealer Error=<pre>"; print_r($error); die;
		if($api_flag){
			$url = Mage::getStoreConfig('general/newgroup/sap_url_json').'ecom_distributor_confirm';
			$parmeters = array("IM_FLAG"=>"U","bapiname"=>"ZBAPI_ECOM_DISTRIBUTOR");
			if(!empty($error)){
				$parmeters['LT_ELOG'] = $error;
				$messagees="<table><tr><td>Dealer Code</td><td>Error</td></tr>";
				foreach($error as $err_txt){
					$messagees.= "<tr><td>".$err_txt['KEY1']."</td><td>".$err_txt['ERROR']."</td></tr>";
				}$messagees.="</table>";
				mail($this->sender,"Havells - Live : Dealer faulty data",$messagees,$this->headers);
			}
			$post_string = json_encode($parmeters); 
			//$post_string = implode('&',array_map(function ($v, $k) { return $k . '=' . $v; },$parmeters,array_keys($parmeters)) );
			//$this->headers = array("Content-type: application/x-www-form-urlencoded"); 
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); 
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_TIMEOUT, 10);
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post_string); // the SOAP request
			curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-type: application/json","Origin: $origin"));			
			$response = curl_exec($ch);	
			curl_close($ch);
		} 	
    }    
}
