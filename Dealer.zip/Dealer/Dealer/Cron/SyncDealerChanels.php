<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace FS\Dealer\Cron;

use Magento\User\Model\User;
use FS\Dealer\Model\Dealer;

/**
 * Find deprecated frontend actions (@see \Magento\Catalog\Api\Data\ProductFrontendActionInterface)
 * Frontend actions deprecates by lifetime.
 * For each scope we have own lifetime.
 */
class SyncDealerChanels
{
    public function __construct(
        \Magento\User\Model\UserFactory $userFactory
    ) {
        $this->_userFactory = $userFactory;
    }

    public function execute()
    {
		$api_flag=true;
		$error=array();
		mail($this->sender,"Havells - Live : Dealer Channels triggers","Dealer Channels triggers ".date("Y-m-d H : i : s"),$this->headers);
		try{
			//$url = "https://mkonnect.havells.com:8082/xmwgw/noaclrfctojson";
			//$url = "https://mkonnect.havells.com:8082/xmwgw/noaclqarfctojson";
			$url = Mage::getStoreConfig('general/newgroup/sap_url').'ecom_dist_division'; 
			$origin=Mage::getStoreConfig('general/newgroup/SAP_origin');
			$parmeters = array("IM_FLAG"=>"R","bapiname"=>"ZBAPI_ECOM_DIST_DIVISION");
			$post_string = implode('&',array_map(function ($v, $k) { return $k . '=' . $v; },$parmeters,array_keys($parmeters)) );
			$getData=http_build_query($parmeters);
			$url=$url.'?'.$getData;
			$this->headers = array("Content-type: application/x-www-form-urlencoded","Origin: $origin"); 
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); 
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_TIMEOUT, 10000);
			//curl_setopt($ch, CURLOPT_POST, true);
			//curl_setopt($ch, CURLOPT_POSTFIELDS, $post_string); // the SOAP request
			curl_setopt($ch, CURLOPT_HTTPHEADER, $this->headers);			
			$response = curl_exec($ch);	
			//mail($this->sender,"Havells - Live : SAP Api dealer chanel data",  $response   ,$this->headers);  die("emailing data");
			//echo "Error=".curl_strerror(curl_errno($ch)); 
			//echo "<pre>dfgdfg"; print_r($response); die;
			$file = fopen($this->basepath."cron_logs/dealer-channel".date("Y-m-d").".txt","a+");
			fwrite($file," = dealer ID = "."\n <br>".$response);
			fclose($file); 
			if(curl_errno($ch))
			{
				mail($this->sender,"Havells - Live : SAP Api dealer chanel not working",curl_strerror(curl_errno($ch)),$this->headers);
				//echo 'error:' . curl_strerror(curl_errno($ch)); exit;
			} else {
				$resp = json_decode($response,true);
				//echo "<pre>"; print_r($resp['LT_DIST_DIV']); die;
				try{
					foreach($resp['LT_DIST_DIV'] as $key => $dealer){
						if($key > 0){
							if($dealer['VTWEG']!=23){
								continue;
							}
							if(empty($dealer['KUNNR'])){
								$error[]=array("KEY1"=>$dealer['KUNNR'],"ERROR"=>"Dealer code can not be empty.");
								continue;
							}
							if(empty($dealer['VTWEG'])){
								$error[]=array("KEY1"=>$dealer['KUNNR'],"ERROR"=>"Distribution channel can not be empty");
								continue;
							}
							if(empty($dealer['LGORT'])){
								$error[]=array("KEY1"=>$dealer['KUNNR'],"ERROR"=>"Storage Location can not be empty");
								continue;
							}
							if(empty($dealer['WERKS']))
							{
								$error[]=array("KEY1"=>$dealer['KUNNR'],"ERROR"=>"Plant code can not be empty");
								continue;
							}
							if((!empty($dealer['KUNNR'])) && (!empty($dealer['LGORT'])) && (!empty($dealer['VTWEG'])) && (!empty($dealer['WERKS'])))
							{
								$users = Mage::getModel('dealer/distributionchannel')->getCollection()
								->addFieldToFilter('dealer_code',$dealer['KUNNR'])
								->addFieldToFilter('distribution_channel',$dealer['VTWEG'])
								//->addFieldToFilter('plant_code',$dealer['WERKS'])
								->addFieldToFilter('div_code',$dealer['SPART']);
								//->addFieldToFilter('storage_location',$dealer['LGORT']);
								
									//->addFieldToFilter('dealer_type',$dealer['KTEXT'])
								//echo "sdfdsf".$users->getSelect()->assemble(); die;
								//print_r($users->getData()); die("tis");
								if(count($users->getData()) > 0){
									foreach($users as $user_mapping){
											$user_mapping->setStatus($dealer['STATUS'])->setPlantCode($dealer['WERKS'])->setStorageLocation($dealer['LGORT'])->save(); 
									}
								}else{
									try {
										$dealers=Mage::getModel('dealer/distributionchannel');
										/* $dealer->setDealerCode($dealer['KUNNR'])
											->setDistributionChannel($dealer['VTWEG'])
											->setDivision($dealer['SPART'])
											->setDealerType($dealer['KTEXT'])
											->setStatus($dealer['STATUS'])
											->setCreatedDate($dealer['ERDAT'])
										->save(); */
										 $dealers->setData(array(
											'distribution_channel' => $dealer['VTWEG'],
											'dealer_code' => $dealer['KUNNR'],
											'plant_code'    => $dealer['WERKS'],
											'div_code' => $dealer['SPART'],
											'storage_location'  =>$dealer['LGORT']
										));
										//print_r($dealers->getData()); die;
										$dealers->save(); 
									}catch(Exception $e){
										mail($this->sender,"Havells - Live : Dealer chanel update cron issue",$e->getMessage()."<br>DealerData=".json_encode($dealer),$this->headers);
									}
								}
								//print_r($user_mapping->getData()); die;
								$lastDealerCode = $dealer['KUNNR'];
								$lastDistibustionChanel=$dealer['VTWEG'];
								$lastDivision = $dealer['SPART'];
								
								$file = fopen($this->basepath."cron_logs/dealer-channel".date("Y-m-d").".txt","a+");
								fwrite($file,"dealer ID = ".$dealer['KUNNR']."--Channel=".$dealer['VTWEG']."--Division=".$dealer['SPART']."---Plant Code---".$dealer['WERKS']."--Storage--".$dealer['LGORT']."\n <br>");
								fclose($file);
								unset($dealer);
								unset($user_mapping);
								}
							}
						}
						if(!empty($error)){
							$messagees="<table><tr><td>Dealer Code</td><td>Error</td></tr>";
							foreach($error as $err_txt){
								$messagees.= "<tr><td>".$err_txt['KEY1']."</td><td>".$err_txt['ERROR']."</td></tr>";
							}$messagees.="</table>";
							mail($this->sender,"Havells - LIVE : Dealer Distribution channel faulty data",$messagees,$this->headers);
						}
						//echo "<pre>"; print_r($error); die;
						/* $url = "https://mkonnect.havells.com:8082/xmwgw/noaclrfctojson";
						$url = Mage::getStoreConfig('general/newgroup/sap_url');
						$parmeters = array("IM_FLAG"=>"U","bapiname"=>"ZBAPI_ECOM_DIST_DIVISION","KEY1"=>$lastDealerCode,"KEY2"=>$lastDistibustionChanel,"KEY3"=>$lastDivision);
						$post_string = implode('&',array_map(function ($v, $k) { return $k . '=' . $v; },$parmeters,array_keys($parmeters)) );
						$this->headers = array("Content-type: application/x-www-form-urlencoded"); 
						$ch = curl_init();
						curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
						curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); 
						curl_setopt($ch, CURLOPT_URL, $url);
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
						curl_setopt($ch, CURLOPT_TIMEOUT, 10);
						curl_setopt($ch, CURLOPT_POST, true);
						curl_setopt($ch, CURLOPT_POSTFIELDS, $post_string); // the SOAP request
						curl_setopt($ch, CURLOPT_HTTPHEADER, $this->headers);			
						$response = curl_exec($ch);	 */
					}catch (Exception $e) {
						mail($this->sender,"Havells - Live : Dealer chanel update data issue",$e->getMessage(),$this->headers);
					}
 				}
			   curl_close($ch);
			}catch (Exception $e) {
				//Zend_Debug::dump($e->getMessage());
				mail($this->sender,"Havells - Live : Dealer chanel update cron issue",$e->getMessage(),$this->headers);
			}	
    }
}
