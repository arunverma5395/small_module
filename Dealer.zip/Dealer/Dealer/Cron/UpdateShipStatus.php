<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace FS\Dealer\Cron;

use Magento\User\Model\User;
use FS\Dealer\Model\Dealer;

/**
 * Find deprecated frontend actions (@see \Magento\Catalog\Api\Data\ProductFrontendActionInterface)
 * Frontend actions deprecates by lifetime.
 * For each scope we have own lifetime.
 */
class UpdateShipStatus
{
    public function __construct(
        \Magento\User\Model\UserFactory $userFactory
    ) {
        $this->_userFactory = $userFactory;
    }

    public function execute()
    {
		mail($this->sender,"Havells - Live : Update Dealers triggers","Update Dealers triggers ".date("Y-m-d H : i : s")." from ip address = ".$this->ip,$this->headers);
		try{
			//$url = "https://mkonnect.havells.com:8082/xmwgw/noaclrfctojson"; // development
			// $url = "https://mkonnect.havells.com:8082/xmwgw/noaclqarfctojson"; // LIVE
			$api_flag=true;
			$url = Mage::getStoreConfig('general/newgroup/sap_url');
			$parmeters = array("IM_FLAG"=>"R","bapiname"=>"ZBAPI_ECOM_DISTRIBUTOR");
			$post_string = implode('&',array_map(function ($v, $k) { return $k . '=' . $v; },$parmeters,array_keys($parmeters)) );
			$this->headers = array("Content-type: application/x-www-form-urlencoded"); 
			//echo $url."and ".$post_string; die;
			$ch = curl_init();
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); 
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post_string); // the SOAP request
            curl_setopt($ch, CURLOPT_HTTPHEADER, $this->headers);			
			$response = curl_exec($ch);

			//echo "Error=".curl_strerror(curl_errno($ch)); 
			//echo "<pre>dfgdfg"; print_r($response); die;
			if(curl_errno($ch))
			{
				$api_flag=false;
				mail($this->sender,"Havells - Live Error : SAP Api update dealer not working",curl_strerror(curl_errno($ch)),$this->headers);
				//echo 'error:' . curl_strerror(curl_errno($ch));
			} else {
				$file = fopen($this->basepath."cron_logs/Dealer-update.txt","a+");
				fwrite($file,"=============== date=".date("Y-m-d, H:i:s")." \n <br>=========================");
				$resp = json_decode($response,true);

				//echo "<pre>"; print_r($resp['LT_DISTRIBUTOR']); die;
				try {
					$role = 5;
					foreach($resp['LT_DISTRIBUTOR'] as $key => $dealer){
						if($key > 0)
						{
							if($dealer['KUNNR'] == 'CEM0076')
							{
								continue;
							}
							if($dealer['KUNNR'] == 'CPA0501'|| $dealer['KUNNR'] == 'CDB0008')
							{
								$user = Mage::getModel('admin/user');
								$userInfo = Mage::getModel('dealer/info')->load($dealer['KUNNR'], 'dealer_code');
							
								/* $userInfo->setData(array(
										"entity_id" => $inc_id,
										"dealer_code"=>$dealer['KUNNR'],
										"firm_name"=>$dealer['NAME1'],
										"tin_no"=>$dealer['J_1ILSTNO'],
										"address1"=>$dealer['ADDRESS1'],
										"address2"=>$dealer['ADDRESS2'],
										"cst_no"=>$dealer['J_1ICSTNO'],
										"mobile"=>$dealer['PHONE_NO'],
										"city"=>$dealer['VKBUR_DESC'],
										"state"=>$dealer['STATE_CODE'],
										"pin"=>$dealer['POST_CODE'],
										"contact_first_name"=>$dealer['NAMEV'],
										"contact_last_name"=>$dealer['LNAME'],
										"pan" => $dealer['J_1IPANNO']
								)); */
								$userInfo->setDealerCode($dealer['KUNNR'])
									->setFirm_name($dealer['NAME1'])
									->setTinNo($dealer['J_1ILSTNO'])
									->setGsTinNo($dealer['STCD3'])
									->setAddress1($dealer['ADDRESS1'])
									->setAddress2($dealer['ADDRESS2'])
									->setCstNo($dealer['J_1ICSTNO'])
									->setMobile($dealer['PHONE_NO'])
									->setCity($dealer['VKBUR_DESC'])
									->setState($dealer['GST_ST_NAME'])
									->setPin($dealer['POST_CODE'])
									->setCinNo($dealer['CIN'])
									->setStateCode($dealer['GST_ST_CODE'])
									->setStateName($dealer['GST_ST_NAME'])
									->setContactFirstName($dealer['NAMEV'])
									->setContactLastName($dealer['LNAME'])
									->setPan($dealer['J_1IPANNO'])
									->setKamPernr($dealer['KAM_PERNR'])
									->setKamName($dealer['KAM_NAME'])
									->setKamMobile($dealer['KAM_MOBILE'])
									->setKamEmail($dealer['KAM_EMAIL']);

								$userInfo->save();
								fwrite($file,"-------------------- \n data=".json_encode($dealer)."\n <br>");
								fclose($file);
							} else {
								continue;
							}
						}
					}
					if(!empty($resp['LT_ELOG']))
					{
						mail($this->sender,"Havells - Live Error :Dealer Data updade issue","Error returned ".$resp['LT_ELOG']." \n Full response \n ".$response,$this->headers);	
						/* //$url = "https://mkonnect.havells.com:8082/xmwgw/noaclrfctojson";
						$url = Mage::getStoreConfig('general/newgroup/sap_url');
						$parmeters = array("IM_FLAG"=>"U","bapiname"=>"ZBAPI_ECOM_DISTRIBUTOR","LT_ELOG"=>array("KEY1"=>$lastDealerCode,"KEY2"=>"","KEY3"=>""));
						$post_string = implode('&',array_map(function ($v, $k) { return $k . '=' . $v; },$parmeters,array_keys($parmeters)) );
						$this->headers = array("Content-type: application/x-www-form-urlencoded"); 
						$ch = curl_init();
						curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
						curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); 
						curl_setopt($ch, CURLOPT_URL, $url);
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
						curl_setopt($ch, CURLOPT_TIMEOUT, 10);
						curl_setopt($ch, CURLOPT_POST, true);
						curl_setopt($ch, CURLOPT_POSTFIELDS, $post_string); // the SOAP request
						curl_setopt($ch, CURLOPT_HTTPHEADER, $this->headers);			
						$response = curl_exec($ch);	*/
					}
				} catch (Exception $e) {
					$api_flag=false;
					mail($this->sender,"Havells - Live Error :Dealer Data updade issue",$e->getMessage(),$this->headers);
				}
			}
		} catch (Exception $e) {
			mail($this->sender,"Havells - Live Error : Dealer Data Curl issue",$e->getMessage(),$this->headers);
		}	
    }    
}
