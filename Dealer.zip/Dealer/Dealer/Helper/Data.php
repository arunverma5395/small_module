<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace FS\Dealer\Helper;
 
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
	const CATEGORY_ROOT_ID = '2';
	const DEALER_ROLE_ID = '3';
	
	
	protected $_authSession;
	
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Backend\Model\Auth\Session $authSession
    ) {
		$this->_authSession = $authSession;
        parent::__construct($context);
    }
    
    // CATEGORY FUNCTIONS
    
    
    
    // ADMIN USER FUNCTIONS
    
    public function getCurrentUserRoleId(){
		return $this->getLoggedInUserRoleId();
	}
    
    public function getLoggedInUserRoleId(){
		return $this->_authSession->getUser()->getAclRole();
	}
    
    public  function getLoggedInUser(){
		return $this->_authSession->getUser();
	}
	
    public function getCurrentAdminUser(){		
		return $this->getLoggedInUser();
	}	
}
