/**
 * Select All Functionality
 */
require([
  "jquery",
],function($){
	"use strict";
	
		$(".scalable.task:first span span span").text("Download Inventory");
		var expanded = 0;

		jQuery(".selectBox").click(function() {
		  var checkboxes = document.getElementById("checkboxes");
		  if (!expanded) {
		  	jQuery('#checkboxes').addClass('customdropdown');
			// jQuery("#checkboxes").css("display", "block");
			// jQuery("#checkboxes").css("position", "absolute");
			// jQuery("#checkboxes").css("background", "#e3e3e3");
			// jQuery("#checkboxes").css("overflow", "auto");
			// jQuery("#checkboxes").css("padding", "0 2px");
			// jQuery("#checkboxes").css("width", "700px");
			// jQuery("#checkboxes").css("right", "0px");
			// jQuery("#checkboxes").css("top", "205px");
			// jQuery("#checkboxes").css("text-align", "left");
			checkboxes.style.display = "block";
			expanded = 1;
		  } else {
			checkboxes.style.display = "none";
			expanded = 0;
		  }
		});

		jQuery("#slctall").click(function () {
			jQuery(".slctall").prop('checked', jQuery(this).prop('checked'));
		});

		jQuery("#button1").click(function() {
			var favorite = [];
			jQuery.each(jQuery("input[name='slctall']:checked"), function() {
				favorite.push(jQuery(this).val());
			});

			var uniqueArray = [];
			var i = 0;
			var item_count = (favorite.length-1);

			for(i=0; i<=item_count; i++) {
				if(uniqueArray.indexOf(favorite[i]) === -1){
					uniqueArray.push(favorite[i]);
				}
			}

			/* var data_val = JSON.stringify(Object.assign({}, favorite)); */
			var url = jQuery('#uploadForm1').prop('action');
			var parts = url.split("/");
			var last_part = parts[parts.length-2];

			if(uniqueArray.length == 0) {
				jQuery("#slt_bx").css("background-color", "#ed6502");
				return false;
			} else {
				jQuery("#slt_bx").css("background-color", "#fff");
				jQuery("#loading-mask").css("display", "block");
				jQuery.ajax({
					type: "GET",
					url: "../../../inventoryexport/key/"+last_part,
					dataType: 'text',
					showLoader: true,
					data:'cat_ids='+uniqueArray,

					success: function(response) {
						/* window.location.href = 'data:application/csv;charset=utf-8,' + encodeURIComponent(response); */
						var encodedUri = 'data:application/csv;charset=utf-8,' + encodeURIComponent(response);
						var link = document.createElement("a");
						link.setAttribute("href", encodedUri);
						link.setAttribute("download", "sample_inventory.csv");
						link.innerHTML= "Download done";
						document.body.appendChild(link);
						link.click();
						jQuery("#loading-mask").css("display", "none");
					},
					error: function(response) {
						/**/ console.log('error'); /**/
					},
				});
			} 
		});
});
