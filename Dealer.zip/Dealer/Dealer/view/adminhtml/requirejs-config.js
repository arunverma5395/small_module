var config = {
    map: {
        '*': {
            dealerSelectAll: 'FS_Dealer/js/select_all'
        }
    },
    shim: {
        dealerSelectAll: {
            deps: ['jquery']
        }
    }
};
